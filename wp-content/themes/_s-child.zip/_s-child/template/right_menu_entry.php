<?php
$img_forder_menu = get_stylesheet_directory_uri() . "/img/menu/";
?>

<div class="right_list_entry">
    <div class="right_item menu_entry">
        応募<br>する
        <a href="#entryform" class="a"></a>
    </div>
    <div class="right_item menu_top" id="page_top">
        <i class="fas fa-arrow-up"></i><br>TOP
    </div>
</div>