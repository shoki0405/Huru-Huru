<?php
$img_forder_menu = get_stylesheet_directory_uri() . "/img/menu/";
?>

<div class="right_list">
    <div class="right_item menu_top" id="page_top">
        <i class="fas fa-arrow-up"></i><br>TOP
    </div>
</div>