<div class="bottom_menu">
    <div class="menu_top" id="page_top_sp">
        <i class="fas fa-arrow-up"></i><br>TOP
    </div>
</div>