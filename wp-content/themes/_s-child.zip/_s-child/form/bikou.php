<div class="bikou">
    <div class="heading">
        備考
    </div>
    <div class="col">
        <textarea name="bikou" id="" cols="30" rows="10" class="bikou_text">
●お食事の有無
●送迎の有無
●買い物の有無
などオプション詳細、保護者在宅のシッティングの場合などご依頼内容の詳細を入力してください。
        </textarea>
        <div>
            ※お申し込み後、手配の状況を含めてこちらからメールにてご連絡いたします。<br>
            その際、緊急連絡先、かかりつけ病院など詳細をお伺いいたします。
        </div>
    </div>

</div>