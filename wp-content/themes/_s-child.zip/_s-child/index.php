<?php
get_header();
get_template_part("template/right_menu");
?>

test

<?php
get_footer();
?>