<div class="bikou">
    <div class="heading">
        備考
    </div>
    <div class="col">
        <textarea name="bikou" id="" cols="30" rows="10" class="bikou_text"></textarea>
        <div>
            ※お申し込み後、手配の状況を含めてこちらからメールにてご連絡いたします。<br>
            その際、緊急連絡先、かかりつけ病院など詳細をお伺いいたします。
        </div>
    </div>

</div>